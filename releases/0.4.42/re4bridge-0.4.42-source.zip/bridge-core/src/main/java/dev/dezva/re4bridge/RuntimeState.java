package dev.dezva.re4bridge;
import com.google.gson.JsonObject;
import java.io.IOException;
public record RuntimeState(boolean available,boolean fresh,int scene,long flags,boolean enemiesAvailable,boolean actionAvailable,long contacts,long corrections,long actions,long receivedNs) {
    public boolean scripted(long now){return available && fresh && scene==1 && now>=receivedNs && now-receivedNs<500_000_000L;}
    public static RuntimeState parse(JsonObject j,long now) throws IOException {
        try{
            if(!bool(j,"available") || !bool(j,"fresh"))return new RuntimeState(j.get("available").getAsBoolean(),false,2,0,false,false,0,0,0,now);
            return new RuntimeState(true,true,(int)number(j,"scene",2),number(j,"flags",0xffffffffL),bool(j,"enemies_available"),bool(j,"action_available"),number(j,"enemy_contacts",0xffffffffL),number(j,"enemy_corrections",0xffffffffL),number(j,"actions",0xffffffffL),now);
        }catch(RuntimeException e){throw new IOException("Invalid native runtime state",e);}
    }
    private static boolean bool(JsonObject j,String key){var p=j.getAsJsonPrimitive(key);if(!p.isBoolean())throw new IllegalArgumentException();return p.getAsBoolean();}
    private static long number(JsonObject j,String key,long max){var p=j.getAsJsonPrimitive(key);long value=p.getAsLong();if(!p.isNumber() || value<0 || value>max || !p.getAsString().equals(Long.toString(value)))throw new IllegalArgumentException();return value;}
}
