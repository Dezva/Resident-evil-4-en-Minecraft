#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "cube_policy.h"
static CubeCommand shared,*cube_command=&shared;
static unsigned mode,barriers;
static void MemoryBarrier(void) {
    barriers++;
    if (mode==1 && barriers==1) {shared.sequence=3;shared.epoch=99;}
    if (mode==1 && barriers==2) {shared.stamp=41;shared.epoch=9;shared.sequence=4;}
    if (mode==2) shared.sequence|=1;
}
/* ACTUAL_READER */
int main(void) {
    shared=(CubeCommand){.magic=0x52453454,.version=6,.sequence=2,.enabled=1,.epoch=7,.stamp=40};
    CubeCommand out={0};CubeCommand before=shared;
    assert(cube_command_requested());shared.enabled=0;assert(!cube_command_requested());shared.enabled=1;
    assert(cube_command_read(&out) && out.epoch==7 && !memcmp(&shared,&before,sizeof(shared)));
    mode=1;barriers=0;assert(cube_command_read(&out) && out.epoch==9 && out.stamp==41 && out.sequence==4 && barriers==4);
    mode=2;barriers=0;assert(!cube_command_read(&out) && barriers==6);
    barriers=0;assert(!cube_command_requested());
    mode=0;shared.sequence=4;shared.reserved=1;assert(!cube_command_read(&out));shared.reserved=0;
    shared.magic=0;assert(!cube_command_read(&out));shared.magic=0x52453454;shared.version=1;assert(!cube_command_read(&out));
    shared.version=2;assert(!cube_command_read(&out));shared.version=3;assert(!cube_command_read(&out));shared.version=4;assert(!cube_command_read(&out));shared.version=6;shared.mode=3;assert(!cube_command_read(&out));
    shared.mode=1;shared.bounds[0]=123;assert(cube_command_read(&out) && out.mode==1 && out.bounds[0]==123);
    shared.mode=2;assert(!cube_command_read(&out));shared.count=2;
    shared.origin[0]=999;shared.boxes[1][5]=1000;
    assert(cube_command_read(&out) && out.count==2 && out.origin[0]==999 && out.boxes[1][5]==1000);
    shared.count=CUBE_MAX_BOXES+1;assert(!cube_command_read(&out));shared.count=2;
    shared.style=4;assert(!cube_command_read(&out));shared.style=0;
    shared.style=1;assert(cube_command_read(&out) && out.style==1);
    shared.style=2;assert(cube_command_read(&out) && out.style==2);
    shared.style=3;assert(!cube_command_read(&out));shared.tile_count=1;assert(cube_command_read(&out));
    shared.collisions=1;assert(!cube_command_read(&out));shared.arm_generation=7;assert(cube_command_read(&out));
    shared.material_reserved=1;assert(cube_command_read(&out) && block_collision_count(&out)==0);shared.material_reserved=4;assert(!cube_command_read(&out));shared.material_reserved=0;
    shared.mode=1;assert(!cube_command_read(&out));
    shared.mode=2;memset(out.materials,0xA5,sizeof(out.materials));memset(out.pixels,0xA5,sizeof(out.pixels));
    assert(cube_collision_command_read(&out) && out.arm_generation==7 && out.boxes[1][5]==1000);
    for(unsigned i=3168;i<sizeof(out);i++)assert(((unsigned char*)&out)[i]==0xA5); // no image/UV copy
    shared.sequence|=1;assert(!cube_collision_command_read(&out));shared.sequence++;
    shared.material_reserved=4;assert(!cube_collision_command_read(&out));shared.material_reserved=0;
    cube_command=NULL;assert(!cube_command_read(&out));
    puts("Cube command reader: readonly complete snapshot, torn retry, odd/malformed rejection and no cached activation passed");
}
