@echo off
setlocal
cd /d "%~dp0"
py -3 -c "import sys" >nul 2>nul
if errorlevel 1 goto python
py -3 tools\re4_object_probe.py
goto end
:python
python tools\re4_object_probe.py
:end
pause
