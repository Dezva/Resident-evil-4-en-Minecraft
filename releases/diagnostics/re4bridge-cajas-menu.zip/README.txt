Ejecuta junto a una caja sin romper y con el dialogo de recogida abierto si es posible. Solo lectura. Comparte cajas-menu.json.
