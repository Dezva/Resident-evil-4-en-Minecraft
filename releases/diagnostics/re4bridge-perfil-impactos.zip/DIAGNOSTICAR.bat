@echo off
setlocal
cd /d "%~dp0"
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if not errorlevel 1 goto use_py
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if not errorlevel 1 goto use_python
echo Se requiere Python 3.10 o posterior. Usa el mismo Python con el que ejecutas el host.
goto finished
:use_py
py -3 tools\re4_combat_probe.py
goto finished
:use_python
python tools\re4_combat_probe.py
:finished
pause
