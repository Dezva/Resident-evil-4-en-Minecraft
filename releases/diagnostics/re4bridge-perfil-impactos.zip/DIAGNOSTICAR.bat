@echo off
cd /d "%~dp0"
py -3 tools\re4_combat_probe.py
pause
