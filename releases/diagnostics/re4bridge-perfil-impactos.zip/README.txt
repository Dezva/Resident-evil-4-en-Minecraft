Con RE4 abierto, pulsa F8 si el puente esta activo y ejecuta DIAGNOSTICAR.bat.
No hace falta enfocar RE4 ni pulsar E. No llama ni modifica el juego.
Comparte el informe perfil-impactos.json. Requiere Python 3.10+.
